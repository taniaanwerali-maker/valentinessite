# Valentine Website Hosting Guide

## Option 1: GitHub Pages
1. Go to [GitHub](https://github.com/) and create a new repository.
2. Upload the files from this folder to your repository.
3. Go to **Settings > Pages** and set the source to "main".
4. Your site will be live at `https://yourusername.github.io/repository-name/`.

## Option 2: Netlify
1. Sign up at [Netlify](https://www.netlify.com/).
2. Drag and drop this folder into Netlify's **Drop Site** section.
3. Your site will be hosted instantly.

## Option 3: Vercel
1. Sign up at [Vercel](https://vercel.com/).
2. Create a new project and upload this folder.
3. Click **Deploy**, and your site will be live.

Enjoy your Valentine site! 💖